<!DOCTYPE html>
<html>

<head>
    <title>Insert page</title>
    <link rel="stylesheet" href="css/style1.css">
</head>

<body>
    <div class="wrapper">
        <header class="header">
            <!-- Left box for logo -->
            <div class="left">
                <img src="./img/man-7328236_1280.png" alt="error">
                <div>Ashman fitness</div>
            </div>
            <div class="mid">
                <!-- Mid box for nav -->
                <ul class="navbar">
                    <li> <a href="#" class="active">Home</a></li>
                    <li> <a href="#">About us</a></li>
                    <li><a href="#">Fitness calculator</a></li>
                    <li><a href="#">Contact us</a></li>
                </ul>
            </div>
            <!-- Right box for buttons -->
            <div class="right">
                <button class="btn">Call us now</button>
                <button class="btn">Email us</button>
            </div>
        </header>

        <?php
    // Establish a connection to the database
    $conn = mysqli_connect("localhost", "root", "", "mydb");

    // Check if the connection was successful
    if ($conn === false) {
        die("ERROR: Could not connect. "
            . mysqli_connect_error());
    }

    // Taking all 3 values from the form data(input)
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $age = $_POST['age'];

   // Execute the INSERT query to add data to the 'subscriber' table
    $sql = "INSERT INTO subscriber(fname,lname,age) VALUES ('$fname','$lname','$age')";

    // Check if the query was executed successfully
    if (mysqli_query($conn, $sql)) {
        // Display a success message
        echo "<h3>data stored in a database successfully."
            . " Please browse your localhost php my admin"
            . " to view the updated data</h3>";

        // Display the entered data
        echo nl2br("\n$fname\n $lname\n $age\n ");
    } else {
        // Display an error message if the query fails
        echo "ERROR: Hush! Sorry $sql. "
            . mysqli_error($conn);
    }
    // Close the database connection
    mysqli_close($conn);
    ?>

        <footer>
            <div>
                Copyright &copy; www.ashmanfitness.com. All rights reserved!
            </div>
        </footer>
    </div>
</body>

</html>