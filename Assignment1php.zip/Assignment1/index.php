<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscriber Record</title>
    <!-- Linking the css file -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="header">
        <!-- Left box for logo -->
        <div class="left">
            <img src="./img/man-7328236_1280.png" alt="error">
            <div>Ashman fitness</div>
        </div>
        <div class="mid">
            <!-- Mid box for nav -->
            <ul class="navbar">
                <li> <a href="#" class="active">Home</a></li>
                <li> <a href="#">About us</a></li>
                <li><a href="#">Fitness calculator</a></li>
                <li><a href="#">Contact us</a></li>
            </ul>
        </div>
        <!-- Right box for buttons -->
        <div class="right">
            <button class="btn">Call us now</button>
            <button class="btn">Email us</button>
        </div>
    </header>

    <!-- Creating a form for subscribers in a gym -->
    <div class="container">
        <h1>Join the best gym of Rajasthan now</h1>
        <form method="post" action="database.php">
            <div class="form-group">
                <input type="text" name="fname" id="fname" placeholder="Enter your Name">
            </div>
            <div class="form-group">
                <input type="text" name="lname" id="lname" placeholder="Enter your last name">
            </div>
            <div class="form-group">
                <input type="text" name="age" id="age" placeholder="Enter your Age">
            </div>
            <div class="button">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>

    <footer>
        <div>
            Copyright &copy; www.ashmanfitness.com. All rights reserved!
        </div>
    </footer>
</body>
</html>